from django.apps import AppConfig


class ComptesConfig(AppConfig):
    name = 'comptes'
